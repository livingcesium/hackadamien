from flask import Flask
import openai
from ai import *

app = Flask(__name__)
openai.api_key = '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'

def query_chatgpt(query):
	try:
		response = openai.Completion.create(
			engine = "text-davinci-003",
			prompt = query,
			max_tokens = 500,
			n = 1,
			stop = None,
			temperature = 1.0
		)
		answer = response.choices[0].text.strip()
		return answer
	except Exception as e:
		return f"Error: {str(e)}"

@app.route('/')
def index():
	return "<!DOCTYPE html><html><body><h1>ROBODAMIEN FLASK</h1></body></html>"

@app.route('/robodamien/<username>/<request>')
def robodamien(username, request):
    chat_as(username, request)
    get_structured_response(username, request, )
    return "<!DOCTYPE html><html><body><h1>Username: "+ username + " - Request body: " + request + "</h1></body></html>"

if __name__ == '__main__':
	app.run(debug = True)
